package Ejercicio5;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class ChapiChapuzas {
    private static File resolveExerciseFile(String fileName) {
        File exerciseDir = new File("Ejercicio5");
        if (!exerciseDir.isDirectory()) {
            exerciseDir = new File(".");
        }
        return new File(exerciseDir, fileName);
    }

    private static String seleccionarIdioma() {
        while (true) {
            System.out.println("----- Selecciona el idioma a traducir -----");
            System.out.println("1. Inglés");
            System.out.println("2. Francés");
            System.out.println("3. Italiano");
            System.out.println("4. Salir");
            System.out.print("Opción: ");
            String opcion = IO.readln();

            switch (opcion) {
                case "1":
                    return "en";
                case "2":
                    return "fr";
                case "3":
                    return "it";
                case "4":
                    System.out.println("Saliendo del programa...");
                    System.exit(0);
                    return "en";
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        }
    }

    public static void main(String[] args) {
        String language = args.length > 0 ? args[0].replace("-", "") : seleccionarIdioma();

        File exerciseDir = new File("Ejercicio5");
        if (!exerciseDir.isDirectory()) {
            exerciseDir = new File(".");
        }

        Trabajo trabajo = new Trabajo(
                resolveExerciseFile("textoInicial.txt"),
                resolveExerciseFile("textoFinal.txt"),
                language);

        ProcessBuilder pb1 = new ProcessBuilder("cmd", "/c", "check.bat");
        pb1.directory(exerciseDir);
        pb1.redirectInput(trabajo.getSourcePath());

        ProcessBuilder pb2 = new ProcessBuilder("cmd", "/c", "translate.bat", "-" + trabajo.getLanguage());
        pb2.directory(exerciseDir);
        pb2.redirectOutput(trabajo.getDestinationPath());

        try {
            List<Process> processes = ProcessBuilder.startPipeline(List.of(pb1, pb2));
            Process last = processes.getLast();
            last.waitFor();
            System.out.println("Texto traducido guardado en: " + trabajo.getDestinationPath().getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
        }
    }
}
